 ____________________________________________
|                 Terreno                    |
|--------------------------------------------|
| - costo_terreno : double                    |
| - ancho : double                            |
| - largo : double                            |
| - area : double                             |
| - valorMetroCuadrado : double               |
|--------------------------------------------|
| + Terreno(ancho: double, largo: double,     |
|            valorMetroCuadrado: double)      |
| + calcularArea(): double                    |
| + calcularCosto(): double                   |
|____________________________________________|
